from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('verify/', views.verify_identity, name='verify'),
    path('logout/', views.logout_view, name='logout'),
]