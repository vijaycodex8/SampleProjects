from django.db import models
from django.contrib.auth.models import User
from cryptography.fernet import Fernet
import hashlib, uuid, datetime
from django.conf import settings
# Secret key for encryption (store securely in env variables in production)


# Use persistent cipher
cipher = Fernet(settings.FERNET_SECRET_KEY)

class Identity(models.Model):
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    dob = models.DateField()
    uid = models.CharField(max_length=36, unique=True)
    identity_hash = models.CharField(max_length=256)
    blockchain_hash = models.CharField(max_length=256)
    aadhaar_encrypted = models.BinaryField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def set_aadhaar(self, aadhaar_plain):
        """Encrypt and store Aadhaar"""
        self.aadhaar_encrypted = cipher.encrypt(aadhaar_plain.encode())

    def get_aadhaar(self):
        """Decrypt Aadhaar safely"""
        if self.aadhaar_encrypted:
            try:
                return cipher.decrypt(self.aadhaar_encrypted).decode()
            except Exception:
                return "Invalid/Aadhaar Corrupted"
        return None

    def __str__(self):
        return f"{self.user.first_name} ({self.uid})"

# models.py
class VerificationAudit(models.Model):
    identity = models.ForeignKey(Identity, on_delete=models.CASCADE, null=True, blank=True)
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    ip_address = models.GenericIPAddressField()
    status = models.CharField(max_length=50)
    timestamp = models.DateTimeField(auto_now_add=True)