# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import Identity, VerificationAudit
from .forms import RegistrationForm, LoginForm, VerifyForm
import hashlib, uuid, datetime
from cryptography.fernet import Fernet

# ---------------- Blockchain Simulation ----------------
class Block:
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_string = f"{self.index}{self.timestamp}{self.data}{self.previous_hash}"
        return hashlib.sha256(block_string.encode()).hexdigest()


class Blockchain:
    def __init__(self):
        self.chain = []
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis = Block(0, str(datetime.datetime.now()), "Genesis Block", "0")
        self.chain.append(genesis)

    def add_block(self, data):
        prev_block = self.chain[-1]
        new_block = Block(len(self.chain), str(datetime.datetime.now()), data, prev_block.hash)
        self.chain.append(new_block)
        return new_block.hash, new_block.index, new_block.timestamp


# Singleton blockchain instance
blockchain = Blockchain()

# ---------------- Utilities ----------------



def hash_identity(name, dob_str, aadhaar):
    try:
        if not all([name, dob_str, aadhaar]):
            raise ValueError("Missing identity fields for hashing")
        combined = f"{name}{dob_str}{aadhaar}"
        return hashlib.sha256(combined.encode()).hexdigest()
    except Exception as e:
        return str(e)


def generate_uid():
    return str(uuid.uuid4())


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


# ---------------- Views ----------------
def register(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            try:
                username = form.cleaned_data['username'].strip()
                if User.objects.filter(username=username).exists():
                    messages.error(request, "Username already exists")
                    return redirect("register")

                password = form.cleaned_data['password']
                first_name = form.cleaned_data['first_name'].strip()
                user = User.objects.create(
                    username=username,
                    first_name=first_name,
                    password=make_password(password)
                )

                dob = form.cleaned_data['dob']
                dob_str = dob.strftime("%Y-%m-%d")
                aadhaar = form.cleaned_data['aadhaar'].strip()

                uid = generate_uid()
                identity_hash = hash_identity(first_name, dob_str, aadhaar)
                blockchain_hash, block_number, block_timestamp = blockchain.add_block(identity_hash)

                identity = Identity(
                    user=user,
                    dob=dob,
                    uid=uid,
                    identity_hash=identity_hash,
                    blockchain_hash=blockchain_hash
                )
                identity.set_aadhaar(aadhaar)
                identity.save()

                messages.success(request, f"Registered successfully! UID: {uid} (Block {block_number})")
                return redirect("login")

            except Exception as e:
                messages.error(request, f"Registration failed: {e}")
                return redirect("register")

    else:
        form = RegistrationForm()
    return render(request, "register.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username'].strip()
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect("dashboard")
            messages.error(request, "Invalid credentials")
            return redirect("login")
    else:
        form = LoginForm()
    return render(request, "login.html", {"form": form})


@login_required
def dashboard(request):
    try:
        identity = Identity.objects.get(user=request.user)
        audits = VerificationAudit.objects.filter(identity=identity).order_by('-timestamp')

        # Analytics
        total_users = Identity.objects.count()
        total_verifications = VerificationAudit.objects.count()
        verified_count = VerificationAudit.objects.filter(status__icontains="VERIFIED").count()
        tampered_count = VerificationAudit.objects.filter(status__icontains="TAMPERED").count()

        analytics = {
            "Total Users": total_users,
            "Total Verifications": total_verifications,
            "Verified Count": verified_count,
            "Tampered Count": tampered_count,
            "Verified %": round((verified_count / total_verifications) * 100, 2) if total_verifications else 0,
            "Tampered %": round((tampered_count / total_verifications) * 100, 2) if total_verifications else 0,
        }

    except Identity.DoesNotExist:
        messages.error(request, "Identity not found")
        return redirect("login")
    except Exception as e:
        messages.error(request, f"Error loading dashboard: {e}")
        audits = []
        analytics = {}

    return render(request, "dashboard.html", {
        "identity": identity,
        "audits": audits,
        "analytics": analytics
    })

# views.py
def verify_identity(request):
    status = None
    details = None
    history = []

    if request.method == "POST":
        form = VerifyForm(request.POST)
        if form.is_valid():
            try:
                name = form.cleaned_data['name'].strip()
                dob_str = form.cleaned_data['dob'].strftime("%Y-%m-%d")
                aadhaar = form.cleaned_data['aadhaar'].strip()

                if not all([name, dob_str, aadhaar]):
                    raise ValueError("All fields are required for verification.")

                submitted_hash = hash_identity(name, dob_str, aadhaar)

                # Default to tampered
                status = "TAMPERED ❌"
                matched_identity = None

                for identity in Identity.objects.all():
                    real_aadhaar = identity.get_aadhaar()
                    real_hash = hash_identity(identity.user.first_name,
                                              identity.dob.strftime("%Y-%m-%d"),
                                              real_aadhaar)
                    if submitted_hash == real_hash:
                        status = "VERIFIED ✅"
                        matched_identity = identity
                        masked_aadhaar = "XXXXXXXX" + real_aadhaar[-4:]
                        details = {
                            "Name": identity.user.first_name,
                            "DOB": identity.dob.strftime("%Y-%m-%d"),
                            "Aadhaar": masked_aadhaar,
                            "UID": identity.uid,
                            "Blockchain Hash": identity.blockchain_hash,
                            "Timestamp": identity.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                            "Total Verifications": VerificationAudit.objects.filter(identity=identity).count()
                        }
                        # Only take recent 5 verifications if verified
                        history = VerificationAudit.objects.filter(identity=identity).order_by('-timestamp')[:5]
                        break  # stop loop once verified

                # Record the audit regardless of verification result
                ip = get_client_ip(request)
                VerificationAudit.objects.create(
                    identity=matched_identity,  # None if tampered
                    verified_by=request.user if request.user.is_authenticated else None,
                    ip_address=ip,
                    status=status
                )

            except Exception as e:
                status = f"Error during verification: {e}"

    else:
        form = VerifyForm()

    return render(request, "verify.html", {
        "form": form,
        "status": status,
        "details": details,
        "history": history
    })

    return render(request, "verify.html", {
        "form": form,
        "status": status,
        "details": details,
        "history": history  # pass history to template
    })


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect("login")