from django import forms
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

class RegistrationForm(forms.ModelForm):
    dob = forms.DateField(
        label="Date of Birth",
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=['%Y-%m-%d']
    )
    aadhaar = forms.CharField(
        label="Aadhaar Number",
        max_length=12,
        validators=[RegexValidator(r'^\d{12}$', 'Aadhaar must be 12 digits')]
    )
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['first_name', 'username', 'password']

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

class VerifyForm(forms.Form):
    name = forms.CharField(label="Full Name")
    dob = forms.DateField(
        label="Date of Birth",
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=['%Y-%m-%d']
    )
    aadhaar = forms.CharField(
        label="Aadhaar Number",
        max_length=12,
        validators=[RegexValidator(r'^\d{12}$', 'Aadhaar must be 12 digits')]
    )