from cryptography.fernet import Fernet

# Run this once in Python shell
key = Fernet.generate_key()
print(key.decode())  # save this