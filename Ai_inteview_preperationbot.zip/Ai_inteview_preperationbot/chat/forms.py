# chat/forms.py
from django import forms

class ChatForm(forms.Form):
    message = forms.CharField(label="Ask anything", widget=forms.TextInput(attrs={
        "class": "form-input",
        "placeholder": "Type your question...",
        "autocomplete": "off",
    }))

from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm

class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)
