# chat/views.py
import os
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
import re

from openai import OpenAI
from .models import Conversation, Message
from .utils import extract_text

# OpenAI client
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=OPENAI_API_KEY)


# ================= INDEX =================
def index(request):
    """
    Home page showing conversations and the current chat
    """
    conversations = Conversation.objects.order_by("-created_at")[:50]
    conv_id = request.GET.get("c") or request.session.get('current_convo')
    conversation = None
    messages = []

    if conv_id:
        try:
            conversation = Conversation.objects.get(pk=int(conv_id))
            messages = conversation.messages.all()
        except Conversation.DoesNotExist:
            pass

    return render(request, "chatbot.html", {
        "conversations": conversations,
        "conversation": conversation,
        "messages": messages,
    })


# ================= START CONVERSATION =================
@require_POST
def start_conversation(request):
    convo = Conversation.objects.create(title="Resume Screening Chat")
    request.session['current_convo'] = convo.id  # store in session
    return JsonResponse({"id": convo.id})


# ================= CHAT PAGE =================
def chat_page(request, conv_id):
    """
    Show a previous conversation (GET request)
    """
    conversation = get_object_or_404(Conversation, pk=conv_id)
    conversations = Conversation.objects.order_by("-created_at")[:50]
    messages = conversation.messages.all()

    # store current conversation in session
    request.session['current_convo'] = conversation.id

    return render(request, "chatbot.html", {
        "conversations": conversations,
        "conversation": conversation,
        "messages": messages,
    })


# ================= ASK =================
@require_POST
def ask(request, conv_id):
    conversation = get_object_or_404(Conversation, pk=conv_id)

    if conversation.ended:
        return JsonResponse({"error": "Conversation has ended"}, status=400)

    user_question = request.POST.get("message", "").strip()
    resume_file = request.FILES.get("resume")
    jd_file = request.FILES.get("job_description")

    # 🔹 Save resume text ONCE
    if resume_file and not conversation.resume_text:
        conversation.resume_text = extract_text(resume_file)

    # 🔹 Save JD text ONCE
    if jd_file and not conversation.jd_text:
        conversation.jd_text = extract_text(jd_file)

    conversation.save()

    # 🔹 Fetch stored context
    resume_text = conversation.resume_text or ""
    jd_text = conversation.jd_text or ""

    if not user_question and not resume_text and not jd_text:
        return HttpResponseBadRequest("No input provided")

    # 🔹 Save user message ONCE
    Message.objects.create(
        conversation=conversation,
        role=Message.ROLE_USER,
        text=user_question or "[File uploaded]"
    )

    # 🔹 SYSTEM PROMPT (persistent context)
    system_prompt = f"""
You are a professional AI interview coach.

Resume:
{resume_text[:6000] if resume_text else "No resume provided"}

Job Description:
{jd_text[:6000] if jd_text else "No job description provided"}

Rules:
- Use the resume/JD context for ALL future replies
- If user asks a question → answer it
- If user gives no question → ask a relevant interview question
- Ask one question at a time
- Be professional and specific
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": user_question or
            "Ask a relevant interview question based on the uploaded file."
        }
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.3,
            max_tokens=800
        )
        reply = response.choices[0].message.content
    except Exception as e:
        reply = f"AI Error: {e}"

    bot_msg = Message.objects.create(
        conversation=conversation,
        role=Message.ROLE_BOT,
        text=reply
    )

    return JsonResponse({
        "bot": {
            "id": bot_msg.id,
            "text": bot_msg.text
        }
    })

# ================= MESSAGE FEEDBACK =================
@require_POST
def message_feedback(request, msg_id):
    liked = request.POST.get("liked")

    try:
        msg = Message.objects.get(pk=msg_id, role=Message.ROLE_BOT)
    except Message.DoesNotExist:
        return JsonResponse({"error": "Message not found"}, status=404)

    if liked is None:
        return HttpResponseBadRequest("Missing liked parameter")

    msg.liked = liked.lower() == "true"
    msg.save(update_fields=["liked"])
    return JsonResponse({"status": "ok"})


# ================= END CONVERSATION =================
@require_POST
def end_conversation(request, conv_id):
    conversation = get_object_or_404(Conversation, pk=conv_id)
    conversation.final_rating = request.POST.get("rating") or None
    conversation.final_comment = request.POST.get("comment", "")
    conversation.ended = True
    conversation.save()
    return JsonResponse({"status": "ok"})


# ================= DELETE CONVERSATION =================
@csrf_exempt
def delete_conversation(request, id):
    if request.method != "POST":
        return JsonResponse({"status": "invalid"}, status=405)

    try:
        Conversation.objects.get(id=id).delete()
        return JsonResponse({"status": "ok"})
    except Conversation.DoesNotExist:
        return JsonResponse({"status": "error"}, status=400)


# ================= USER AUTH =================
def register_view(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        errors = []

        # Username validation
        if not username:
            errors.append("Username is required.")
        elif User.objects.filter(username=username).exists():
            errors.append("Username already exists.")

        # Gmail validation
        gmail_regex = r'^[a-zA-Z0-9._%+-]+@gmail\.com$'
        if not re.match(gmail_regex, email):
            errors.append("Only valid Gmail addresses are allowed.")
        elif User.objects.filter(email=email).exists():
            errors.append("Gmail already registered.")

        # Password validation
        if len(password) < 3:
            errors.append("Password must be at least 3 characters.")
        elif password != confirm_password:
            errors.append("Passwords do not match.")

        if errors:
            return render(request, "register.html", {
                "errors": errors,
                "username": username,
                "email": email
            })

        User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        messages.success(request, "Registration successful. Please login.")
        return redirect("chat:login")

    return render(request, "register.html")


def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password")

        errors = []

        user = authenticate(request, username=username, password=password)
        if user is None:
            errors.append("Incorrect username or password.")

        if errors:
            return render(request, "login.html", {
                "errors": errors,
                "username": username
            })

        login(request, user)
        return redirect("chat:index")  # go to chat index after login

    return render(request, "login.html")


def logout_view(request):
    logout(request)
    return redirect("chat:login")
