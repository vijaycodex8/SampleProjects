# chat/urls.py
from django.urls import path
from . import views

app_name = "chat"

urlpatterns = [
    path("index/", views.index, name="index"),                          # UI with history + start button
    path("start/", views.start_conversation, name="start"),       # create new conversation (AJAX)
    path("chat/<int:conv_id>/", views.chat_page, name="chat_page"),
    path("chat/<int:conv_id>/ask/", views.ask, name="ask"),       # send message -> bot reply (AJAX)
    path("message/<int:msg_id>/feedback/", views.message_feedback, name="message_feedback"),
    path("chat/<int:conv_id>/end/", views.end_conversation, name="end_conversation"),
    path("chat/delete/<int:id>/", views.delete_conversation, name="delete_convo"),
    path("register/", views.register_view, name="register"),
    path("", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
]
