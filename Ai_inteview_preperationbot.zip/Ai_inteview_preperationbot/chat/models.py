# chat/models.py
from django.db import models
from django.utils import timezone

class Conversation(models.Model):
    title = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    ended = models.BooleanField(default=False)
    final_rating = models.PositiveSmallIntegerField(null=True, blank=True)
    final_comment = models.TextField(blank=True)
    resume_text = models.TextField(blank=True, null=True)
    jd_text = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title or f"Conversation {self.id}"


class Message(models.Model):
    ROLE_USER = "user"
    ROLE_BOT = "bot"
    ROLE_CHOICES = ((ROLE_USER, "User"), (ROLE_BOT, "Bot"))

    conversation = models.ForeignKey(Conversation, related_name="messages", on_delete=models.CASCADE)
    role = models.CharField(max_length=8, choices=ROLE_CHOICES)
    text = models.TextField()
    liked = models.BooleanField(null=True, blank=True)  # True = like, False = dislike, None = no feedback
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ("created_at",)

    def __str__(self):
        return f"{self.role}: {self.text[:40]}"
