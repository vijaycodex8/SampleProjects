# chat/admin.py
from django.contrib import admin
from .models import Conversation, Message

class MessageInline(admin.TabularInline):
    model = Message
    fields = ("role", "text", "created_at", "liked")
    readonly_fields = ("role", "text", "created_at")
    extra = 0

@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "created_at", "ended", "final_rating")
    inlines = [MessageInline]

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("id", "conversation", "role", "created_at", "liked")
    list_filter = ("role", "liked")
    search_fields = ("text",)
